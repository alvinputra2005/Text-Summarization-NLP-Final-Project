# Notebook proyek NLP

## Pemrograman V2

Buka [notebook V2](Pipeline_NLP_Video_Pemrograman_V2.ipynb) di Colab dengan runtime GPU, lalu unggah `paket-pemrograman-v2.zip` saat sel 01 memintanya. Notebook melatih Whisper pada klip NSS-ID dan LUMINA. Model peringkas diuji pada IndoSum dan The Vault Function. Acuan The Vault berupa docstring Inggris. Data, prediksi per contoh, dan riwayat validasi dilaporkan per benchmark.

- **NSS-ID Imperative** memakai klip penutur manusia dari split resmi. Paket mengumpulkan subset proyek dengan nama klip lokal. Atribusi Ratna Atika, Suci Dwijayanti, dan Bhakti Yudho Suprapto. [Sumber NSS-ID](https://huggingface.co/datasets/Atika88/Indonesian-ASR-11-Class-Dataset)
- **LUMINA v4** memakai klip Setyaningsih, Chen, Kristian, Handayani, dan Irianto. Paket memasangkan WAV resmi ke video dan membagi klip per penutur. [Sumber LUMINA](https://data.mendeley.com/datasets/8fw93k4rny/4)
- **IndoSum** memakai fold 01 karya Kurniawan dan Louvan. [Sumber IndoSum](https://github.com/kata-ai/indosum)
- **The Vault Function** memakai subset proyek dari revisi `505c679056e49a2a269b64777ee7c496d22e1440` dengan grup repositori yang terpisah antarsplit. CSV menyimpan jalur repositori, commit, dan lisensi asal. [Sumber The Vault](https://huggingface.co/datasets/Fsoft-AIC/the-vault-function)

Jalankan `streamlit run app.py` lalu pilih **Jalankan demo pandas** untuk memproses MP4 sintetis lokal. Demo memperlihatkan transkripsi, OCR, bukti Gemini jika tersedia, dan ringkasan. Skor penelitian berasal dari notebook V2.

